# KIN-030 Push Instructions

## Files included

1. `sites/kin-030/index.html` — The app. Drop straight into the repo.

2. `KIN-030-CATALOG-ENTRY.md` — Append to `Kin Catalog.md` in the repo root.

3. `KIN-030-LANDING-CARD.html` — The card HTML snippet. Add to BOTH:
   - `index.html` (root)
   - `sites/kin-landing/index.html`
   Insert after the KIN-029 card in the tools grid.
   Delay value: 1.65s

## Commit message

KIN-030 Quote: initial release
- Quote generator with flexible line items
- User-controlled prefix + auto-increment numbering
- Freeform international payment fields
- Save as PDF via print stylesheet
- Clipboard export for KIN-031 Invoice
- Defaults system (from, currency, tax, payment)
- Full KIN compliance (dark mode, PWA, demo, bug report)

## After push

- Bump SW cache if updating an existing tool
- Verify Netlify deploy at https://kintools.netlify.app/sites/kin-030/
- Test ?demo=true param

## KIN-030 — Quote

Generate quotes with flexible line items and export to Invoice. Set your prefix, auto-increment numbering, save defaults for repeat use. Clipboard export carries the full document to KIN-031.

- **Category:** Business
- **Creator:** Darren
- **Privacy:** Nothing leaves your device
- **Status:** Live

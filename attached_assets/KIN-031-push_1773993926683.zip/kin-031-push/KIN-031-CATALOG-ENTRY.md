## KIN-031 — Invoice

Turn quotes into invoices and track payment. Import from KIN-030 Quote via clipboard, set your own numbering, mark as unpaid, partial, or paid. Clipboard export carries the full document to KIN-032 Receipt.

- **Category:** Business
- **Creator:** Darren
- **Privacy:** Nothing leaves your device
- **Status:** Live

# KIN-031 Push Instructions

## Files included

1. `sites/kin-031/index.html` — The app. Drop straight into the repo.

2. `KIN-031-CATALOG-ENTRY.md` — Append to `Kin Catalog.md` in the repo root.

3. `KIN-031-LANDING-CARD.html` — Card snippet for BOTH:
   - `index.html` (root)
   - `sites/kin-landing/index.html`
   Insert after the KIN-030 card. Delay: 1.70s

## Commit message

KIN-031 Invoice: initial release
- Import from KIN-030 Quote via clipboard JSON
- User-controlled prefix + auto-increment numbering
- Invoice date and due date fields
- Payment status: unpaid / partial / paid
- Balance tracking with amount paid
- Source quote ID reference
- Freeform international payment fields
- Save as PDF via print stylesheet
- Clipboard export for KIN-032 Receipt
- Defaults system (from, currency, tax, payment)
- Full KIN compliance (dark mode, PWA, demo, bug report)

## After push

- Verify Netlify deploy at https://kintools.netlify.app/sites/kin-031/
- Test ?demo=true param
- Test import: open KIN-030, fill data, tap "Copy for Invoice", open KIN-031, paste

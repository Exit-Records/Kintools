# KIN-032 Push Instructions

## Files included

1. `sites/kin-032/index.html` — The app. Drop straight into the repo.

2. `KIN-032-CATALOG-ENTRY.md` — Append to `Kin Catalog.md` in the repo root.

3. `KIN-032-LANDING-CARD.html` — Card snippet for BOTH:
   - `index.html` (root)
   - `sites/kin-landing/index.html`
   Insert after the KIN-031 card. Delay: 1.75s

## Commit message

KIN-032 Receipt: initial release
- Import from KIN-031 Invoice via clipboard JSON
- Read-only display (no editable fields after import)
- Shows full chain: receipt > invoice > quote references
- Paid amount, method, and date confirmation
- User-controlled receipt prefix + auto-increment numbering
- Empty state when no data loaded
- Save as PDF via print stylesheet
- Full KIN compliance (dark mode, PWA, demo, bug report)

## After push

- Verify Netlify deploy at https://kintools.netlify.app/sites/kin-032/
- Test ?demo=true param
- Full chain test: KIN-030 > Copy for Invoice > KIN-031 > Import > Mark paid > Copy for Receipt > KIN-032 > Import

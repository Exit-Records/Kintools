## KIN-032 — Receipt

Confirm payment with a clean read-only receipt. Import from KIN-031 Invoice via clipboard. Shows full document chain back to the original quote.

- **Category:** Business
- **Creator:** Darren
- **Privacy:** Nothing leaves your device
- **Status:** Live
